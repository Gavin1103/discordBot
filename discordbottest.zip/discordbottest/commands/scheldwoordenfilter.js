module.exports = {
    name: 'scheldwoordenfilter',
    description: 'Dit verwijderd alle scheldwoorden',
    execute(message, args) {




    }
}