const discord = require('discord.js');

module.exports.run = async(client, message, args) => {

    return message.channel.send("hallo");

}

module.exports.help = {
    name: "hallo"
}