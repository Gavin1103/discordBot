const discord = require('discord.js');

module.exports.run = async(client, message, args) => {

    if (!message.member.hasPermission("KICK_MEMBERS")) return message.reply("jij bent gay");
    if (!args[0]) return message.reply("geen gebruiker gevonden");
    if (!args[1]) return message.reply("geef een reden op");

    if (!message.guild.me.hasPermission('KICK_MEMBERS')) return message.reply('geen perms');

    var warnUser = message.guild.member(message.mentions.user.first() || message.guild.members.get(args[0]));

    var reason = args.slice(1).join(" ");

    if (!warnUser) return message.reply("Kan gebruiker niet vinden");

    if (warnUser.hasPermission("MANAGE_MESSAGES")) return message.reply("Je kunt deze gebruiker niet waarschuwen");
}

module.exports.help = {
    name: "warn"
}