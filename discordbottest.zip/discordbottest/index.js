const Discord = require('discord.js');
const client = new Discord.Client();

client.once('ready', () => {
    console.log('Bot1 is online')
});



client.on("message", async message => {
    if (message.channel.type === "dm" || message.author.bot) return;

    const logChannel = client.channels.cache.find(channel => channel.id === "910488308411400242");
    let words = ["nigger", "orange"];

    let foundInText = false;
    for (var i in words) {
        if (message.content.toLowerCase().includes(words[i].toLowerCase())) foundInText = true;
    }

    if (foundInText) {
        let logEmbed = new Discord.MessageEmbed()
            .setDescription(`<@${message.author.id}>Said a bad word`)
            .addField('The message', message.content)
            .addField('Channel', message.guild.channels.cache.get(message.channel.id).toString())
            .setColor('RANDOM')
            .setTimestamp()
        logChannel.send(logEmbed)

        let embed = new Discord.MessageEmbed()
            .setDescription(`You can not say that here`)
            .setColor('RANDOM')
            .setTimestamp()
        let msg = await message.channel.send(embed);
        message.delete();
        // msg.delete()
    }
})
client.login("OTEwMTIwOTUzODY5MTIzNTk0.YZOOMA.BfeEdb_J_pyqBsCxIVIa_S3ejNQ");